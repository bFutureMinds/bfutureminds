package com.hackethon.controller;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.social.connect.ConnectionRepository;
import org.springframework.social.connect.support.ConnectionFactoryRegistry;
import org.springframework.social.facebook.api.Facebook;
import org.springframework.social.facebook.api.Post;
import org.springframework.social.linkedin.api.LinkedIn;
import org.springframework.social.linkedin.api.impl.LinkedInTemplate;
import org.springframework.social.linkedin.connect.LinkedInConnectionFactory;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.social.twitter.api.Twitter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hackethon.models.MasterAnalyzedUserInformation;
import com.hackethon.models.UserSocialInformation;
import com.hackethon.nlp.service.main.SocialExecuterService;
import com.hackethon.utilities.DateAdapter;

@Controller
@RequestMapping("/")
public class SocialController {

	private Facebook facebook;
	private Twitter twitter;
	private LinkedIn linkedin;
	private ConnectionRepository connectionRepository;
	// private ArrayList<UserSocialInformation> userSocialInformations = new
	// ArrayList<UserSocialInformation>();
	private UserSocialInformation userSocialInformation = null;
	private DateAdapter dateAdapter = new DateAdapter();

	public SocialController() {
		// TODO Auto-generated constructor stub
	}

	@Inject
	public SocialController(Facebook facebook, Twitter twitter,
			ConnectionRepository connectionRepository) {
		this.facebook = facebook;
		this.twitter = twitter;

		this.connectionRepository = connectionRepository;
	}
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {
		
		return "index";
	}
	@RequestMapping(value = "/social/twitterdata", method = RequestMethod.GET)
	public String helloTwitter(Model model) {
		if (connectionRepository.findPrimaryConnection(Twitter.class) == null) {
			return "redirect:/connect/twitter";
		}

		if (null == this.userSocialInformation) {
			this.userSocialInformation = new UserSocialInformation();
			this.userSocialInformation.setUserid(twitter.userOperations()
					.getUserProfile().getName());
			String name[] = twitter.userOperations()
					.getUserProfile().getName().split(" ");
			if(name.length>=1){
			this.userSocialInformation.setFname(twitter.userOperations()
					.getUserProfile().getName().split(" ")[0]);
			this.userSocialInformation.setLname(twitter.userOperations()
					.getUserProfile().getName().split(" ")[1]);
			}
			/*
			 * List<String> timelineInformation = new ArrayList<String>();
			 * this.userSocialInformation
			 * .setTimelineInformation(timelineInformation);
			 */
		}
		List<String> tweetList = new ArrayList<String>();
		if (twitter.timelineOperations().getUserTimeline().size() != 0) {
			for (Tweet data : twitter.timelineOperations().getUserTimeline()) {
				tweetList.add(data.getText());

			}
		}
		this.userSocialInformation.setTweetInformation(tweetList);
		ArrayList<UserSocialInformation> userSocialInformations = new ArrayList<UserSocialInformation>();
		prepareTimeLineList();
		System.out.println(userSocialInformation);
		model.addAttribute("userSocialInformations", userSocialInformations);
		userSocialInformations.add(userSocialInformation);
		return "facebookdata";
	}

	@RequestMapping(value = "/social/linkedindata", method = RequestMethod.GET)
	public String helloLinkedin(Model model) {
		ConnectionFactoryRegistry registry = new ConnectionFactoryRegistry();
		registry.addConnectionFactory(new LinkedInConnectionFactory(
				"756uzvr0u5nm5f", "93SzdYQyzkWW2E0h"));
		String accessToken = "AQWOTviK80NNw5eDpToAa_4r8rxuCeCYVdiDhwsft5S2Hs0p0c_6ciOb5N7MIoIiWy2NulyvVH95bUZglJ7PFl4u2LQmpHlkmYnSkjrRsgAVdDFmh_Rkp7nL3jI_esFO3L6rSVZzB-3aaaJgl44ggv3NWoQYy0afTRg7ZUJg9grDZ1X50Oo"; 
		LinkedIn linkedin = new LinkedInTemplate(accessToken);

		if (null == this.userSocialInformation) {
			this.userSocialInformation = new UserSocialInformation();
			this.userSocialInformation.setUserid(linkedin.profileOperations()
					.getUserProfile().getEmailAddress());
			this.userSocialInformation.setEmail(linkedin.profileOperations()
					.getUserProfile().getEmailAddress());
			this.userSocialInformation.setFname(linkedin.profileOperations()
					.getUserProfile().getFirstName());
			this.userSocialInformation.setLname(linkedin.profileOperations()
					.getUserProfile().getLastName());
			/*
			 * List<String> timelineInformation = new ArrayList<String>();
			 * this.userSocialInformation
			 * .setTimelineInformation(timelineInformation);
			 */
		}
		this.userSocialInformation.setHeadline(linkedin.profileOperations()
				.getUserProfile().getHeadline());
		ArrayList<UserSocialInformation> userSocialInformations = new ArrayList<UserSocialInformation>();
		prepareTimeLineList();
		System.out.println(userSocialInformation);
		model.addAttribute("userSocialInformations", userSocialInformations);
		userSocialInformations.add(userSocialInformation);
		return "facebookdata";
	}

	@RequestMapping(value = "/social/userdata", method = RequestMethod.GET)
	public String helloFacebook(Model model) {
		if (connectionRepository.findPrimaryConnection(Facebook.class) == null) {
			return "redirect:/connect/facebook";
		}
		if (null == this.userSocialInformation) {
			userSocialInformation = new UserSocialInformation();
			List<String> timelineInformation = new ArrayList<String>();
			userSocialInformation.setTimelineInformation(timelineInformation);
		} else {
			userSocialInformation
					.setTimelineInformation(new ArrayList<String>());
		}
		userSocialInformation.setFname(facebook.userOperations()
				.getUserProfile().getFirstName());
		userSocialInformation.setLname(facebook.userOperations()
				.getUserProfile().getLastName());
		userSocialInformation.setGender(facebook.userOperations()
				.getUserProfile().getGender());
		userSocialInformation.setEmail(facebook.userOperations()
				.getUserProfile().getEmail());
		userSocialInformation.setUserid(facebook.userOperations()
				.getUserProfile().getName());
		try {
			userSocialInformation.setBirthDate(dateAdapter.unmarshal(facebook
					.userOperations().getUserProfile().getBirthday()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<String> facebookPost = new ArrayList<String>();

		for (Post post : facebook.feedOperations().getFeed()) {
			if (null != post.getMessage()) {
				System.out.println("post.getMessage()="+post.getMessage());
				facebookPost.add(post.getMessage());
			}
		}
		userSocialInformation.setFacebookpost(facebookPost);
		prepareTimeLineList();
		ArrayList<UserSocialInformation> userSocialInformations = new ArrayList<UserSocialInformation>();
		userSocialInformations.add(userSocialInformation);
		model.addAttribute("userSocialInformations", userSocialInformations);
		System.out.println(userSocialInformation);
		return "facebookdata";
	}

	@RequestMapping(value = "/social/nlpexecute", method = RequestMethod.POST)
	public String execute(HttpServletRequest request, Model model) {
		ArrayList<UserSocialInformation> userSocialInformations = new ArrayList<UserSocialInformation>();
		prepareTimeLineList();
		userSocialInformations.add(userSocialInformation);
		SocialExecuterService executerService = new SocialExecuterService();
		MasterAnalyzedUserInformation analyzedUserInformation = executerService
				.execute(userSocialInformations);
		model.addAttribute("campaigns", executerService.getCampaigns());
		model.addAttribute("analyzedUserInformations",
				analyzedUserInformation.getAnalyzedUserInformations());
		return "process";
	}

	private void prepareTimeLineList() {
		List<String> data = new ArrayList<String>();
		if (null != this.userSocialInformation.getFacebookpost()) {
			data.addAll(this.userSocialInformation.getFacebookpost());
		}
		if (null != this.userSocialInformation.getTweetInformation()) {
			data.addAll(this.userSocialInformation.getTweetInformation());
		}
		this.userSocialInformation.setTimelineInformation(data);

	}

}
