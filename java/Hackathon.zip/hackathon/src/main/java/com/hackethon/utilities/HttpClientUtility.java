package com.hackethon.utilities;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.hackethon.models.UserSocialInformation;

public class HttpClientUtility {
	/*public static void main(String[] args) {
		String url = "https://www.facebook.com/dialog/oauth?client_id=1087475804678466&redirect_uri=";
		HttpClientUtility clientUtility = new HttpClientUtility();
		String data = clientUtility.httpRequest(url);
		clientUtility.getFacebookUserData(data);
	}*/

	public UserSocialInformation getFacebookUserData(String Data) {
		UserSocialInformation userSocialInformation = new UserSocialInformation();
		JSONParser parser = new JSONParser();

		JSONObject jsonObject;
		try {
			jsonObject = (JSONObject) parser.parse(Data);

			try {
				userSocialInformation.setBirthDate(new DateAdapter()
						.unmarshal(jsonObject.get("birthday").toString()));
			} catch (Exception e) {
				e.printStackTrace();
			}
			userSocialInformation.setUserid(jsonObject.get("name").toString());
			userSocialInformation.setEmail(jsonObject.get("email").toString());
			userSocialInformation
					.setGender(jsonObject.get("gender").toString());
			userSocialInformation.setLname(jsonObject.get("last_name")
					.toString());
			userSocialInformation.setFname(jsonObject.get("first_name")
					.toString());
			JSONObject postObj = (JSONObject) jsonObject.get("posts");
			JSONArray postData = (JSONArray) postObj.get("data");
			ArrayList<String> timelines = new ArrayList<String>();
			for (Object object : postData) {
				JSONObject data = (JSONObject) object;
				if (null != data.get("message")) {
					timelines.add(data.get("message").toString());
				}
			}
			userSocialInformation.setTimelineInformation(timelines);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return userSocialInformation;

	}

	public String httpRequest(String url) {
		if (null == url) {
			return "";
		}
		StringBuffer result = new StringBuffer();
		try {
			HttpClient client = HttpClientBuilder.create().build();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			System.out.println("Response Code : " + url);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			System.out.println(result.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result.toString();
	}
}
