package com.hackethon.salesforce;

import java.io.InputStream;
import java.net.Authenticator;
import java.util.List;
import java.util.Properties;

import com.hackethon.models.AnalyzedUserInformation;
import com.hackethon.models.Campaign;
import com.hackethon.models.EventInfo;
import com.hackethon.models.MasterAnalyzedUserInformation;
import com.sforce.soap.partner.PartnerConnection;
import com.sforce.soap.partner.QueryResult;
import com.sforce.soap.partner.sobject.SObject;
import com.sforce.ws.ConnectionException;
import com.sforce.ws.ConnectorConfig;

public class SalesforceUtility {
    private PartnerConnection connection;
    InputStream inputStr = null;
    Properties prop = new Properties();

    public void pushAnalyzedData(
            MasterAnalyzedUserInformation masterAnalyzedUserInformation) {

        try {
            inputStr = getClass().getResourceAsStream("config.properties");
            // load a properties file
            prop.load(inputStr);
            ConnectorConfig config = new ConnectorConfig();
            config.setUsername(prop.getProperty("sf.ETLUserName"));
            config.setPassword(prop.getProperty("sf.ETLPassword"));

            config.setAuthEndpoint(prop.getProperty("sf.EndPointURL"));

            config.setTraceMessage(false);
            config.setPrettyPrintXml(false);

          /*  config.setProxy(prop.getProperty("proxyHost"),
                    Integer.parseInt(prop.getProperty("proxyPort")));*/
            connection = new PartnerConnection(config);
            if (login()) {
                System.out.println("Logined for pushing Analyzed social Data..");
                connection.create(getSObjects(masterAnalyzedUserInformation));
                logout();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    private SObject[] getSObjects(
            MasterAnalyzedUserInformation masterAnalyzedUserInformation) {
        SObject[] data = new SObject[masterAnalyzedUserInformation
                .getAnalyzedUserInformations().size()];
        int incr = 0;
        for (AnalyzedUserInformation analyzedUserInformation : masterAnalyzedUserInformation
                .getAnalyzedUserInformations()) {
            SObject object = new SObject("Data_Feed__c");
            object.setField("Name", analyzedUserInformation.getFname() + " "
                    + analyzedUserInformation.getLname());
            object.setField("User_Name__c", analyzedUserInformation.getEmail());
            object.setField("Email__c", analyzedUserInformation.getEmail());
            object.setField("Anniversary_Date__c",
                    analyzedUserInformation.getMarriageDate());
            object.setField("Campaign__c",
                    getData(analyzedUserInformation.getIdentifyCampaigns()));
            object.setField("DOB__c", analyzedUserInformation.getBirthDate());
            object.setField("Event_Type__c",
                    getEventData(analyzedUserInformation.getEvents()));
            object.setField("First_Name__c", analyzedUserInformation.getFname());
            object.setField("Last_Name__c", analyzedUserInformation.getLname());
            data[incr] = object;
            incr++;
        }
        return data;
    }

    private String getData(List<String> data) {
        String output = new String();
        for (String string : data) {
            if (output.trim().length() == 0) {
                output = string;
            } else {
                output = output + "," + string;
            }
        }
        return output;
    }

    private String getEventData(List<EventInfo> data) {
        String output = new String();
        for (EventInfo eventInfo : data) {
            if (output.trim().length() == 0) {
                output = eventInfo.name();
            } else {
                output = output + "," + eventInfo.name();
            }
        }
        return output;
    }

    public Campaign[] retreiveCampaignData() {
        Campaign[] data = null;
        try {
            inputStr = getClass().getResourceAsStream("config.properties");
            // load a properties file
            prop.load(inputStr);
            ConnectorConfig config = new ConnectorConfig();
            config.setUsername(prop.getProperty("sf.ETLUserName"));
            config.setPassword(prop.getProperty("sf.ETLPassword"));
            config.setAuthEndpoint(prop.getProperty("sf.EndPointURL"));
            config.setTraceMessage(false);
            config.setPrettyPrintXml(false);
          /*  config.setProxy(prop.getProperty("proxyHost"),
                    Integer.parseInt(prop.getProperty("proxyPort")));*/
            connection = new PartnerConnection(config);
            if (login()) {
                System.out.println("Logined for retreiveCampaignData");
                QueryResult qr = connection
                        .query("select id,name, Keywords__c from Campaign where IsActive =true");
                data = new Campaign[qr.getRecords().length];
                for (int i = 0; i < qr.getRecords().length; i++) {
                    Campaign campaign = new Campaign();
                    campaign.setId(qr.getRecords()[i].getId());
                    String keywords = qr.getRecords()[i]
                            .getField("Keywords__c").toString();
                    campaign.setKeywords(keywords.split(";"));
                    System.out.println("Campaign Id = [ " + qr.getRecords()[i].getId()+"] Campaign Keywords = [ " +keywords+" ]");
                    data[i] = campaign;
                }
                logout();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return data;
    }

    public void logout() {
        try {
            connection.logout();
            System.out.println("Logged out from Sales Force");
        } catch (ConnectionException ce) {

            ce.printStackTrace();
        }
    }

    public boolean login() {
        boolean success = false;

        try {
            Authenticator.setDefault(new ProxyAuthenticator(prop
                    .getProperty("proxyUserName"), prop
                    .getProperty("proxyUserPassword")));
           /* System.setProperty("http.proxyHost", prop.getProperty("proxyHost"));
            System.setProperty("http.proxyPort", prop.getProperty("proxyPort"));*/
            ConnectorConfig config = new ConnectorConfig();
            config.setUsername(prop.getProperty("sf.ETLUserName"));
            config.setPassword(prop.getProperty("sf.ETLPassword"));

            config.setAuthEndpoint(prop.getProperty("sf.EndPointURL"));

            config.setTraceMessage(false);
            config.setPrettyPrintXml(false);

            /*config.setProxy(prop.getProperty("proxyHost"),
                    Integer.parseInt(prop.getProperty("proxyPort")));*/
            connection = new PartnerConnection(config);
            success = true;
        } catch (ConnectionException ce) {
            ce.printStackTrace();
            /*
             * } catch (FileNotFoundException fnfe) { fnfe.printStackTrace();
             */
        }
        return success;
    }

}
