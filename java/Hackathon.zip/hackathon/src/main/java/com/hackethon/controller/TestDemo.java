package com.hackethon.controller;

import org.springframework.social.connect.support.ConnectionFactoryRegistry;
import org.springframework.social.linkedin.api.Group;
import org.springframework.social.linkedin.api.LinkedIn;
import org.springframework.social.linkedin.api.LinkedInProfile;
import org.springframework.social.linkedin.api.impl.LinkedInTemplate;
import org.springframework.social.linkedin.connect.LinkedInConnectionFactory;

public class TestDemo {

	/*public static void main(String[] args) {
		ConnectionFactoryRegistry registry = new ConnectionFactoryRegistry();
        registry.addConnectionFactory(new LinkedInConnectionFactory(
            "756uzvr0u5nm5f",
            "93SzdYQyzkWW2E0h"));
        String accessToken = "AQWOTviK80NNw5eDpToAa_4r8rxuCeCYVdiDhwsft5S2Hs0p0c_6ciOb5N7MIoIiWy2NulyvVH95bUZglJ7PFl4u2LQmpHlkmYnSkjrRsgAVdDFmh_Rkp7nL3jI_esFO3L6rSVZzB-3aaaJgl44ggv3NWoQYy0afTRg7ZUJg9grDZ1X50Oo"; // The access token granted after OAuth authorization
		LinkedIn linkedin = new LinkedInTemplate(accessToken);
		System.out.println("1"+linkedin.profileOperations().getUserProfile().getFirstName());
		System.out.println("2"+linkedin.profileOperations().getUserProfile().getHeadline());
		if (linkedin.connectionOperations().getConnections().size() != 0) {
			for (LinkedInProfile data : linkedin.connectionOperations().getConnections()) {
				System.out.println(data.getFirstName());
			}
		}
		
		

	}*/

}
