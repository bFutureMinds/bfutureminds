package com.hackethon.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.hackethon.utilities.DateAdapter;

@XmlRootElement(name = "UserSocialInformation")
@XmlType()
public class UserSocialInformation implements Serializable {
	/**
     * 
     */
	private static final long serialVersionUID = 1L;

	private String userid;
	private String fname;
	private String lname;
	private Date birthDate;
	private String status;
	private String gender;
	private String email;
	private Date marriageDate;
	private String headline;
	private boolean isWorkAnniversary;
	List<String> timelineInformation = new ArrayList<String>();
	List<String> tweetInformation = new ArrayList<String>();
	List<String> linkedInformation = new ArrayList<String>();
	List<String> facebookpost;

	@XmlAttribute
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	@XmlElement
	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	@XmlElement
	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	@XmlElement
	@XmlJavaTypeAdapter(DateAdapter.class)
	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	@XmlElement
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@XmlElement
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isWorkAnniversary() {
		return isWorkAnniversary;
	}

	public void setWorkAnniversary(boolean isWorkAnniversary) {
		this.isWorkAnniversary = isWorkAnniversary;
	}

	@XmlElement
	@XmlJavaTypeAdapter(DateAdapter.class)
	public Date getMarriageDate() {
		return marriageDate;
	}

	public void setMarriageDate(Date marriageDate) {
		this.marriageDate = marriageDate;
	}

	@XmlElement
	public List<String> getTimelineInformation() {
		return timelineInformation;
	}

	public void setTimelineInformation(List<String> timelineInformation) {
		this.timelineInformation = timelineInformation;
	}

	public List<String> getTweetInformation() {
		return tweetInformation;
	}

	public void setTweetInformation(List<String> tweetInformation) {
		this.tweetInformation = tweetInformation;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getHeadline() {
		return headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	@XmlElement
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public List<String> getFacebookpost() {
		return facebookpost;
	}

	public void setFacebookpost(List<String> facebookpost) {
		this.facebookpost = facebookpost;
	}

	public List<String> getLinkedInformation() {
		return linkedInformation;
	}

	public void setLinkedInformation(List<String> linkedInformation) {
		this.linkedInformation = linkedInformation;
	}

	@Override
	public String toString() {
		return "UserSocialInformation [userid=" + userid + ", fname=" + fname
				+ ", lname=" + lname + ", birthDate=" + birthDate + ", status="
				+ status + ", gender=" + gender + ", email=" + email
				+ ", marriageDate=" + marriageDate + ", headline=" + headline
				+ ", isWorkAnniversary=" + isWorkAnniversary
				+ ", timelineInformation=" + timelineInformation
				+ ", tweetInformation=" + tweetInformation
				+ ", linkedInformation=" + linkedInformation
				+ ", facebookpost=" + facebookpost + "]";
	}

	

}
