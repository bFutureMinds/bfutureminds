package com.hackethon.utilities;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class DateAdapter extends XmlAdapter<String, Date> {
    DateFormat f = new SimpleDateFormat("MM/dd/yyyy");

    public Date unmarshal(String v) throws Exception {
    	if(null == v) {
    		return null;
    	}
        return f.parse(v);
    }

   
    public String marshal(Date v) throws Exception {
        return f.format(v);
    }
}
