package com.hackethon.models;

public enum EventInfo {
    BIRTHDAY,
    MARRIAGE,
    WORK_ANNIVERSARY,
    NEW_BORN,
    TRAVEL,
    NEW_JOB
}
