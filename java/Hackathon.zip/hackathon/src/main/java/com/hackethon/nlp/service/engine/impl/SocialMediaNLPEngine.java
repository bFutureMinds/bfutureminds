package com.hackethon.nlp.service.engine.impl;

import java.util.ArrayList;
import java.util.List;

import com.hackethon.models.AnalyzedUserInformation;
import com.hackethon.models.Campaign;
import com.hackethon.models.EventInfo;
import com.hackethon.models.UserSocialInformation;
import com.hackethon.nlp.service.engine.AnalyzerEngine;
import com.hackethon.nlp.service.engine.rule.EventRule;



public class SocialMediaNLPEngine implements AnalyzerEngine {
    EventRule eventRule = new EventRule();

    public AnalyzedUserInformation process(
            UserSocialInformation socialInformation, Campaign[] campaigns) {
        System.out.println(" ************** Analyzer process start here *************************");
        System.out.println(" Input Social Data : - " + socialInformation);
        // 1. Set Basic Information
        AnalyzedUserInformation analyzedUserInformation = setPrimaryInformation(socialInformation);

        // 2. Identify Birthday Marriage and work Anniversary events
        List<EventInfo> eventInfos = detectEvents(socialInformation);
        analyzedUserInformation.setEvents(eventInfos);

        // 3. Identify the Campaigns from UserTime line comments.
        List<String> identifyCampaigns = identifyCampaignOnTimeline(
                socialInformation, campaigns);
        analyzedUserInformation.setIdentifyCampaigns(identifyCampaigns); 
        System.out.println(" Result Data : - " + analyzedUserInformation);
        System.out.println(" ************** Analyzer process End here *************************");
        return analyzedUserInformation;
    }

    private AnalyzedUserInformation setPrimaryInformation(
            UserSocialInformation socialInformation) {
        AnalyzedUserInformation analyzedUserInformation = new AnalyzedUserInformation();
        analyzedUserInformation.setUserid(socialInformation.getUserid());
        analyzedUserInformation.setEmail(socialInformation.getEmail());
        analyzedUserInformation.setFname(socialInformation.getFname());
        analyzedUserInformation.setLname(socialInformation.getLname());
        analyzedUserInformation.setBirthDate(socialInformation.getBirthDate());
        analyzedUserInformation.setMarriageDate(socialInformation
                .getMarriageDate());
        analyzedUserInformation.setStatus(socialInformation.getStatus());
        return analyzedUserInformation;
    }

    @SuppressWarnings("unused")
    private List<EventInfo> detectEvents(UserSocialInformation socialInformation) {
        List<EventInfo> events = new ArrayList<EventInfo>();
        
        // Check Birthday and Marriage
        if (eventRule.isBirthOrMarriageDate(socialInformation.getBirthDate())) {
            System.out.println("  - Birthdate is match with todays date..");
            events.add(EventInfo.BIRTHDAY);
        }
        if (eventRule
                .isBirthOrMarriageDate(socialInformation.getMarriageDate())) {
            System.out.println("  - Marriage Date is match with todays date..");
            events.add(EventInfo.MARRIAGE);
        }
        // Is Work Anniversary
        if (socialInformation.isWorkAnniversary()) {
            events.add(EventInfo.WORK_ANNIVERSARY);
        }
        return events;
    }

    private List<String> identifyCampaignOnTimeline(
            UserSocialInformation socialInformation, Campaign[] campaigns) {
        List<String> identiyCampaigns = new ArrayList<String>();
        IdentifyCampaigns identifyCampaigns = new IdentifyCampaigns();
        for (int i = 0; i < campaigns.length; i++) {
            if (identifyCampaigns.isCampaignApplicable(
                    socialInformation.getTimelineInformation(), campaigns[i])) {
                identiyCampaigns.add(campaigns[i].getId());
            }
        }
        return identiyCampaigns;
    }
}
