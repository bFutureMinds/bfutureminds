package com.hackethon.models;

import java.util.List;

public class MasterAnalyzedUserInformation {
    List<AnalyzedUserInformation> analyzedUserInformations;

    public List<AnalyzedUserInformation> getAnalyzedUserInformations() {
        return analyzedUserInformations;
    }

    public void setAnalyzedUserInformations(
            List<AnalyzedUserInformation> analyzedUserInformations) {
        this.analyzedUserInformations = analyzedUserInformations;
    }
}
