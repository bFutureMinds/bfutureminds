package com.hackethon.utilities;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.hackethon.models.MasterCampaign;
import com.hackethon.models.UserSocialInformation;

public class XMLExchange {
    private static final String FILE_NAME = "socialdata.xml";

    private static Object jaxbXMLToObject() {
        try {
            JAXBContext context = JAXBContext.newInstance(MasterCampaign.class);
            Unmarshaller un = context.createUnmarshaller();
            return un.unmarshal(new File(FILE_NAME));
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static void jaxbObjectToXML(UserSocialInformation information) {

        try {
            JAXBContext context = JAXBContext
                    .newInstance(UserSocialInformation.class);
            Marshaller m = context.createMarshaller();
            // for pretty-print XML in JAXB
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            File file = new File(FILE_NAME);
            m.marshal(information, file);

        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }
}
