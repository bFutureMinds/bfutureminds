package com.hackethon.nlp.service.engine;

import com.hackethon.models.AnalyzedUserInformation;
import com.hackethon.models.Campaign;
import com.hackethon.models.UserSocialInformation;


public interface AnalyzerEngine {
    public AnalyzedUserInformation process(UserSocialInformation socialInformation,Campaign[] campaigns );
}
