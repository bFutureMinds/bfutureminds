package com.hackethon.models;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
@SuppressWarnings("restriction")
@XmlRootElement(name = "Campaign")
@XmlType()
public class Campaign implements Serializable {
    private static final long serialVersionUID = -9851113064940012L;
    private String Id;
    private String[] keywords;
    @XmlAttribute
    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }
    @SuppressWarnings("restriction")
    @XmlElement
    public String[] getKeywords() {
        return keywords;
    }

    public void setKeywords(String[] keywords) {
        this.keywords = keywords;
    }

}
