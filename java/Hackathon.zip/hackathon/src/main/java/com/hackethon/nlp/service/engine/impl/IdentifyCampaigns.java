package com.hackethon.nlp.service.engine.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

import com.hackethon.models.Campaign;

public class IdentifyCampaigns {

	public boolean isCampaignApplicable(List<String> timelines,
			Campaign campaign) {
		boolean isCampaignApplicable = false;
		for (String timeline : timelines) {
			if (isCampaignKewordsOnTimeline(timeline, campaign)) {
				isCampaignApplicable = true;
				break;
			}
		}
		return isCampaignApplicable;
	}

	private boolean isCampaignKewordsOnTimeline(String timeline,
			Campaign campaign) {
		if (null == timeline || null == campaign) {
			return false;
		}

		boolean isPresent = false;
		// 1. Tokenized the timeline sentence
		String[] tokens = sentences(timeline.toLowerCase());
		// 2. Search the campaign kewords in timeline
		for (String keyword : campaign.getKeywords()) {
			for (String token : tokens) {
				if (null != keyword && null != token
						&& token.contains(keyword.toLowerCase())) {
					isPresent = true;
					break;
				}
			}
			if (isPresent) {
				break;
			}
		}
		return isPresent;
	}

	private String[] sentences(String timeline) {

		InputStream modelIn = getClass().getResourceAsStream("en-sent.bin");
		try {
			SentenceModel model = new SentenceModel(modelIn);
			SentenceDetectorME sdetector = new SentenceDetectorME(model);
			String sentences[] = sdetector.sentDetect(timeline);
			System.out.print("  - Timeline Token : -");
			for (int i = 0; i < sentences.length; i++) {
				System.out.print(" [" + sentences[i] + "]-");
			}
			System.out.println();
			return sentences;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (modelIn != null) {
				try {
					modelIn.close();
				} catch (IOException e) {
				}
			}
		}
		return null;

	}

	private String[] tokenizer(String timeline) {
		InputStream modelIn = getClass().getResourceAsStream("en-token.bin");
		try {
			TokenizerModel model = new TokenizerModel(modelIn);
			opennlp.tools.tokenize.Tokenizer tokenizer = new TokenizerME(model);
			String tokens[] = tokenizer.tokenize(timeline);
			System.out.print("  - Timeline Token : -");
			for (int i = 0; i < tokens.length; i++) {
				System.out.print(" [" + tokens[i] + "]-");
			}
			System.out.println();
			return tokens;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (modelIn != null) {
				try {
					modelIn.close();
				} catch (IOException e) {
				}
			}
		}
		return null;
	}
}
