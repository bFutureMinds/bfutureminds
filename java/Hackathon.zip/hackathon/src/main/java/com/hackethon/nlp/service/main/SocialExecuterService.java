package com.hackethon.nlp.service.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.hackethon.models.AnalyzedUserInformation;
import com.hackethon.models.Campaign;
import com.hackethon.models.MasterAnalyzedUserInformation;
import com.hackethon.models.UserSocialInformation;
import com.hackethon.nlp.service.engine.AnalyzerEngine;
import com.hackethon.nlp.service.engine.impl.SocialMediaNLPEngine;
import com.hackethon.salesforce.SalesforceUtility;

public class SocialExecuterService {
	private Campaign[] campaigns;

	/*
	 * public static void main(String args[]) { SocialExecuterService
	 * executerService = new SocialExecuterService(); executerService.execute();
	 * }
	 */

	public List<UserSocialInformation> fetchSocialData() {
		List<UserSocialInformation> informations = getSocialUserInformation();
		return informations;
	}

	public Campaign[] getCampaigns() {
		return campaigns;
	}

	public MasterAnalyzedUserInformation execute(
			List<UserSocialInformation> informations) {
		// Object Creation
		SalesforceUtility salesforceUtility = new SalesforceUtility();
		AnalyzerEngine analyzerEngine = new SocialMediaNLPEngine();
		MasterAnalyzedUserInformation masterAnalyzedUserInformation = new MasterAnalyzedUserInformation();
		List<AnalyzedUserInformation> data = new ArrayList<AnalyzedUserInformation>();

		// 1 Fetch User Social Information
		if (null == informations) {
			informations = fetchSocialData();
		}
		System.out.println("1 - > Fetch Social User Data from Media.Size = "
				+ informations.size());

		// 2 Fetch Campaign Data from Sales force site
		Campaign[] campaigns = salesforceUtility.retreiveCampaignData();
		this.campaigns = campaigns;
		System.out
				.println("2- > Fetch Campaign Data from Salesforce. Campaigns Count = "
						+ campaigns.length);
		int counter = 0;
		for (UserSocialInformation userSocialInformation : informations) {
			System.out
					.println("************"
							+ counter
							+ ":- Start Processing User Social Information ****************");
			// 3 Apply social Analyzer and put Analyzed user data in array list.
			AnalyzedUserInformation analyzedUserInformation = analyzerEngine
					.process(userSocialInformation, campaigns);
			data.add(analyzedUserInformation);
			System.out
					.println("************"
							+ counter
							+ ":- End Processing User Social Information ****************");
			counter++;
		}
		masterAnalyzedUserInformation.setAnalyzedUserInformations(data);
		salesforceUtility.pushAnalyzedData(masterAnalyzedUserInformation);
		System.out.println("4 --> Data is loaded in salesforce...");
		return masterAnalyzedUserInformation;

	}

	private List<UserSocialInformation> getSocialUserInformation() {
		List<UserSocialInformation> informations = new ArrayList<UserSocialInformation>();
		// 1st Sample Data
		UserSocialInformation information1 = new UserSocialInformation();
		information1.setFname("Latesh");
		information1.setLname("Suryawanshi");
		information1.setEmail("lateshsuryawanshi@gmail.com");
		information1.setUserid("lateshsuryawanshi@gmail.com");
		information1.setMarriageDate(new Date(System.currentTimeMillis()));
		information1.setBirthDate(new Date(System.currentTimeMillis()));
		List<String> timeline1 = new ArrayList<String>();
		timeline1.add("Happy Birthday");
		timeline1.add("Travelling from UK to Pune");
		timeline1.add("many many happry returns of the day");
		information1.setTimelineInformation(timeline1);
		informations.add(information1);

		// 2nd Sample Data
		UserSocialInformation information2 = new UserSocialInformation();
		information2.setFname("Pankaj");
		information2.setLname("Mehra");
		information2.setEmail("pankajMehra@gmail.com");
		information2.setUserid("pankajmehra@gmail.com");
		information2.setMarriageDate(new Date(System.currentTimeMillis()));
		information2.setBirthDate(new Date(System.currentTimeMillis()));
		List<String> timeline2 = new ArrayList<String>();
		timeline2.add(" Planning for shopping and Movie");
		timeline2.add("Travelling from UK to Pune");
		timeline2.add("weddinginvitations");
		information2.setTimelineInformation(timeline2);
		informations.add(information2);

		// 3rd Sample Data
		UserSocialInformation information3 = new UserSocialInformation();
		information3.setFname("Yogesh");
		information3.setLname("Bisht");
		information3.setEmail("yogeshbisht@gmail.com");
		information3.setUserid("yogeshbisht@gmail.com");
		information3.setMarriageDate(getDate("12-06-1982 10:20:56"));
		information3.setBirthDate(getDate("12-06-1982 10:20:56"));
		List<String> timeline3 = new ArrayList<String>();
		timeline3.add(" New Family Member ..Baby Boy");
		timeline3.add("Travelling from South Africa to Pune");
		timeline3.add("newborn baby boy");
		information3.setTimelineInformation(timeline3);
		informations.add(information3);

		// 4th Sample Data

		UserSocialInformation information4 = new UserSocialInformation();
		information4.setFname("Mourya");
		information4.setLname("Naveen");
		information4.setEmail("MouryaNaveen@gmail.com");
		information4.setUserid("MouryaNaveen@gmail.com");
		information4.setMarriageDate(getDate("20-06-1982 10:20:56"));
		information4.setBirthDate(getDate("20-06-1982 10:20:56"));
		List<String> timeline4 = new ArrayList<String>();
		timeline4.add(" New Family Member ..Baby Boy angel");
		timeline4.add("Travelling from South Africa to Pune");
		timeline4.add("Aaniversary trip");
		information4.setTimelineInformation(timeline4);
		informations.add(information4);

		// 5th Sample Data
		UserSocialInformation information5 = new UserSocialInformation();
		information5.setFname("Gunwant");
		information5.setLname("Patidar");
		information5.setEmail("Gunwant.Patidar@barclaycard.co.uk");
		information5.setUserid("Gunwant.Patidar@barclaycard.co.uk");
		information5.setMarriageDate(getDate("15-06-1982 10:20:56"));
		information5.setBirthDate(getDate("15-06-1982 10:20:56"));
		List<String> timeline5 = new ArrayList<String>();
		timeline5.add("New Family Member ..Baby Boy");
		timeline5.add("Travelling from South Africa to Pune");
		timeline5.add("Marriage Party");
		information5.setTimelineInformation(timeline5);
		informations.add(information5);

		return informations;
	}

	private Date getDate(String strgDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
		String dateInString = strgDate;
		Date date = null;
		try {
			date = sdf.parse(dateInString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
}
