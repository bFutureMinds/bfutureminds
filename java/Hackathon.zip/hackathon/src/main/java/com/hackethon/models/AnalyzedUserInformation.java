package com.hackethon.models;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class AnalyzedUserInformation implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 7720066981272158845L;

    private String userid;
    private String fname;
    private String lname;
    private Date birthDate;
    private String status;
    private String email;
    private Date marriageDate;
    private List<EventInfo> events;
    private List<String> identifyCampaigns;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getMarriageDate() {
        return marriageDate;
    }

    public void setMarriageDate(Date marriageDate) {
        this.marriageDate = marriageDate;
    }

    public List<EventInfo> getEvents() {
        return events;
    }

    public void setEvents(List<EventInfo> events) {
        this.events = events;
    }

    public List<String> getIdentifyCampaigns() {
        return identifyCampaigns;
    }

    public void setIdentifyCampaigns(List<String> identifyCampaigns) {
        this.identifyCampaigns = identifyCampaigns;
    }

    @Override
    public String toString() {
        return "AnalyzedUserInformation [userid=" + userid + ", fname=" + fname
                + ", lname=" + lname + ", birthDate=" + birthDate + ", status="
                + status + ", email=" + email + ", marriageDate="
                + marriageDate + ", events=" + events + ", identiyCampaigns="
                + identifyCampaigns + "]";
    }
}
