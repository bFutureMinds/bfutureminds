package com.hackethon.models;

import java.io.Serializable;
import java.util.Arrays;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "Campaigns")
@XmlType()
public class MasterCampaign implements Serializable {

    Campaign[] campaigns;

    public MasterCampaign() {
    }

    public MasterCampaign(Campaign[] campaigns) {
        this.campaigns = campaigns;
    }

    @XmlElement
    public Campaign[] getCampaigns() {
        return campaigns;
    }

    public void setCampaigns(Campaign[] campaigns) {
        this.campaigns = campaigns;
    }

    @Override
    public String toString() {
        return "MasterCampaign [campaigns=" + Arrays.toString(campaigns) + "]";
    }
    
}
