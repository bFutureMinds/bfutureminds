package com.hackethon.nlp.service.engine.rule;

import java.text.SimpleDateFormat;
import java.util.Date;

public class EventRule {
    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

    public boolean isBirthOrMarriageDate(Date birthDate) {
        if (null == birthDate) {
            return false;
        }
        Date todayDate = new Date(System.currentTimeMillis());
        String todaysDateStr = sdf.format(todayDate);
        String birthDateStr = sdf.format(birthDate);
        if (todaysDateStr.equalsIgnoreCase(birthDateStr)) {
            return true;
        }
        return false;

    }

}
